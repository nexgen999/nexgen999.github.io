/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useRef, useLayoutEffect } from 'react';
import { motion } from 'motion/react';
import { Copy, Download, RefreshCcw, Palette, Terminal, Layout, Check, Type } from 'lucide-react';

const INITIAL_COLORS = {
  bgColor: '#272727',
  titleColor: '#ffffff',
  logBgColor: '#000000',
  borderColor: '#ffffff',
  barBgColor: '#ffffff',
  progressLabelColor: '#ffffff',
  progressBarColor: '#0037ff',
  logInfoColor: '#ffffff',
  logSuccessColor: '#00ff00',
  logErrorColor: 'red',
  logWarningColor: 'yellow',
};

const INITIAL_TEXTS = {
  titleText: 'Y2JB Autoloader - Powered by UI Design',
  versionString: 'Y2JB 1.3 by Gezine',
  autoloaderVersion: 'v0.5',
  progressText: 'Jailbreak in progress', // Nouveau champ
};

const INITIAL_LAYOUT = {
  // Titre
  titleTop: 60,
  titleLeft: 50,
  titleWidth: 1800,
  titleFontSize: 42,
  titleTextAlign: 'left' as const,
  titleFont: 'monospace',
  
  // Logs
  logTop: 303,
  logLeft: 134,
  logWidth: 1190,
  logHeight: 670,
  logFontSize: 28,
  logBorderWidth: 2,
  logBorderRadius: 8,
  logFont: 'monospace',
  logOpacity: 0.4,
  
  // Progress Bar
  barTop: 428,
  barLeft: 136,
  barWidth: 1200,
  barHeight: 10,
  barBorderWidth: 2,
  barBorderRadius: 16,
  borderOpacity: 1,
  
  // Progress Label
  percentTop: 383,
  percentLeft: 145,
  percentWidth: 1201,
  percentTextAlign: 'left' as const,
  progressFontSize: 30,
  showPercentage: false,
};

const hexToRgba = (hex: string, opacity: number) => {
  const r = parseInt(hex.slice(1, 3), 16);
  const g = parseInt(hex.slice(3, 5), 16);
  const b = parseInt(hex.slice(5, 7), 16);
  return `rgba(${r}, ${g}, ${b}, ${opacity})`;
};

const COLOR_LABELS = {
  bgColor: 'Fond Interface',
  titleColor: 'Texte Principal',
  logBgColor: 'Fond Console',
  borderColor: 'Bordures & Rails',
  barBgColor: 'Fond Rail Barre',
  progressLabelColor: 'Texte Progression',
  progressBarColor: 'Barre de Progression',
  logInfoColor: 'Logs: Info',
  logSuccessColor: 'Logs: Succès',
  logErrorColor: 'Logs: Erreur',
  logWarningColor: 'Logs: Alerte',
};

export default function App() {
  const [colors, setColors] = useState(INITIAL_COLORS);
  const [texts, setTexts] = useState(INITIAL_TEXTS);
  const [layout, setLayout] = useState(INITIAL_LAYOUT);
  const [useBgImage, setUseBgImage] = useState(false);
  const [bgTimestamp, setBgTimestamp] = useState(Date.now());
  const [scale, setScale] = useState(0.4);
  const [activeTab, setActiveTab] = useState<'text' | 'color' | 'layout'>('text');
  const [selectedElement, setSelectedElement] = useState<'title' | 'log' | 'bar' | 'percent' | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    const updateScale = () => {
      if (containerRef.current) {
        const { width, height } = containerRef.current.getBoundingClientRect();
        const scaleW = (width * 0.95) / 1920;
        const scaleH = (height * 0.95) / 1080;
        setScale(Math.min(scaleW, scaleH));
      }
    };
    const resizeObserver = new ResizeObserver(updateScale);
    if (containerRef.current) resizeObserver.observe(containerRef.current);
    updateScale();
    return () => resizeObserver.disconnect();
  }, []);

  const handleColorChange = (key: keyof typeof INITIAL_COLORS, value: string) => {
    setColors((prev) => ({ ...prev, [key]: value }));
  };

  const handleTextChange = (key: keyof typeof INITIAL_TEXTS, value: string) => {
    setTexts((prev) => ({ ...prev, [key]: value }));
  };

  const handleLayoutChange = (key: keyof typeof INITIAL_LAYOUT, value: any) => {
    setLayout((prev) => ({ ...prev, [key]: value }));
  };

  const resetToDefault = () => {
    setColors(INITIAL_COLORS);
    setTexts(INITIAL_TEXTS);
    setLayout(INITIAL_LAYOUT);
  };

  const generateFullJS = async () => {
    try {
      const response = await fetch('/main.js');
      let content = await response.text();
      
      content = content.split('//# sourceMappingURL=')[0].trim();
      
      // Texte & Version
      content = content.replace('const version_string = "Y2JB 1.3 by Gezine";', `const version_string = "${texts.versionString}";`);
      content = content.replace('const autoloader_version = "v0.5";', `const autoloader_version = "${texts.autoloaderVersion}";`);
      content = content.replace('progressLabel.textContent = "Loading...";', `progressLabel.textContent = "${texts.progressText}";`);
      content = content.replace('message="Loading..."', `message="${texts.progressText}"`);
      content = content.replace('window.updateProgress(0, "Running userland exploit...");', `window.updateProgress(0, "${texts.progressText}...");`);
      
      // Fond & UI Base
      if (useBgImage) {
        content = content.replace('autoloader_ui.style.backgroundColor = "#272727";', `autoloader_ui.style.backgroundImage = "url('background.jpg')"; autoloader_ui.style.backgroundSize = "cover"; autoloader_ui.style.backgroundPosition = "center";`);
      } else {
        content = content.replace('autoloader_ui.style.backgroundColor = "#272727";', `autoloader_ui.style.backgroundColor = "${colors.bgColor}";`);
      }
      
      // Reset UI base styles to match emulator exactly
      content = content.replace('autoloader_ui.style.padding = "5px";', `autoloader_ui.style.padding = "0px"; autoloader_ui.style.boxSizing = "border-box";`);
      content = content.replace('autoloader_ui.style.border = "1px solid black";', `autoloader_ui.style.border = "none";`);

      // Police Globale
      content = content.replace('autoloader_ui.style.fontFamily = "Arial, sans-serif";', `autoloader_ui.style.fontFamily = "${layout.titleFont === 'monospace' ? 'monospace' : 'Arial, sans-serif'}";`);

      // Titre Layout & Style
      content = content.replace('title.style.color = "#ccc";', `title.style.color = "${colors.titleColor}";`);
      content = content.replace('title.textContent = "Y2JB Autoloader";', `title.textContent = "${texts.titleText}";`);
      content = content.replace('title.style.fontSize = "42px";', `title.style.fontSize = "${layout.titleFontSize}px";`);
      content = content.replace('title.style.padding = "10px";', `title.style.padding = "0px";`);
      content = content.replace('title.style.marginBottom = "5px";', `title.style.margin = "0px";`);
      
      // Robust title replacement
      if (content.includes('title.style.marginTop = "60px";')) {
        content = content.replace('title.style.marginTop = "60px";', `title.style.position = "absolute"; title.style.top = "${layout.titleTop}px"; title.style.left = "${layout.titleLeft}px"; title.style.width = "${layout.titleWidth}px"; title.style.textAlign = "${layout.titleTextAlign}"; title.style.fontFamily = "${layout.titleFont}";`);
      } else {
        // Fallback for already modified files
        content = content.replace(/title\.style\.top = "[^"]+"; title\.style\.left = "[^"]+"; title\.style\.width = "[^"]+"; title\.style\.textAlign = "[^"]+";/, `title.style.top = "${layout.titleTop}px"; title.style.left = "${layout.titleLeft}px"; title.style.width = "${layout.titleWidth}px"; title.style.textAlign = "${layout.titleTextAlign}";`);
      }
      
      // Log Wrapper Layout & Style
      content = content.replace('logWrapper.style.width = "62%";', `logWrapper.style.width = "${layout.logWidth}px";`);
      content = content.replace('logWrapper.style.height = "62%";', `logWrapper.style.height = "${layout.logHeight}px";`);
      content = content.replace('logWrapper.style.margin = "20px auto 0 auto";', `logWrapper.style.position = "absolute"; logWrapper.style.top = "${layout.logTop}px"; logWrapper.style.left = "${layout.logLeft}px"; logWrapper.style.margin = "0px";`);
      content = content.replace('logWrapper.style.padding = "0px";', `logWrapper.style.padding = "48px"; logWrapper.style.boxSizing = "border-box";`);
      content = content.replace('logWrapper.style.color = "#ccc";', `logWrapper.style.color = "${colors.logInfoColor}";`);
      content = content.replace('logWrapper.style.backgroundColor = "#000";', `logWrapper.style.backgroundColor = "${hexToRgba(colors.logBgColor, layout.logOpacity)}";`);
      content = content.replace('logWrapper.style.fontSize = "28px";', `logWrapper.style.fontSize = "${layout.logFontSize}px"; logWrapper.style.fontFamily = "${layout.logFont}";`);
      content = content.replace('logWrapper.style.border = "2px solid red";', `logWrapper.style.border = "${layout.logBorderWidth}px solid ${hexToRgba(colors.borderColor, layout.borderOpacity)}";`);
      content = content.replace('logWrapper.style.borderRadius = "8px";', `logWrapper.style.borderRadius = "${layout.logBorderRadius}px";`);
      content = content.replace('logWrapper.style.overflowY = "scroll";', `logWrapper.style.overflow = "hidden";`);
      
      // Correction du logContainer (le padding interne du terminal)
      content = content.replace('logContainer.style.padding = "10px";', `logContainer.style.padding = "0px";`);

      // Progress Bar Layout & Style
      content = content.replace('progressBarContainer.style.backgroundColor = "#202020";', `progressBarContainer.style.backgroundColor = "${colors.barBgColor}";`);
      
      if (content.includes('progressBarContainer.style.width = "60%";')) {
        content = content.replace('progressBarContainer.style.width = "60%";', `progressBarContainer.style.width = "${layout.barWidth}px";`);
      }
      
      content = content.replace('progressBarContainer.style.height = "100px";', `progressBarContainer.style.height = "${layout.barHeight}px";`);
      content = content.replace('progressBarContainer.style.border = "2px solid red";', `progressBarContainer.style.border = "${layout.barBorderWidth}px solid ${hexToRgba(colors.borderColor, layout.borderOpacity)}";`);
      content = content.replace('progressBarContainer.style.borderRadius = "16px";', `progressBarContainer.style.borderRadius = "${layout.barBorderRadius}px";`);
      
      if (content.includes('progressBarContainer.style.margin = "0 auto";')) {
        content = content.replace('progressBarContainer.style.margin = "0 auto";', `progressBarContainer.style.position = "absolute"; progressBarContainer.style.top = "${layout.barTop}px"; progressBarContainer.style.left = "${layout.barLeft}px"; progressBarContainer.style.margin = "0px";`);
      }
      
      content = content.replace('progressBarContainer.style.marginTop = "30px";', ``);
      
      // Move label to main UI to allow independent positioning
      if (content.includes('progressBarContainer.appendChild(progressLabel);')) {
        content = content.replace('progressBarContainer.appendChild(progressLabel);', 'autoloader_ui.appendChild(progressLabel);');
      }
      
      content = content.replace('progressLabel.style.color = "#fff";', `progressLabel.style.color = "${colors.progressLabelColor}";`);
      
      if (content.includes('progressLabel.style.fontSize = "42px";')) {
         content = content.replace('progressLabel.style.fontSize = "42px";', `progressLabel.style.fontSize = "${layout.progressFontSize}px"; progressLabel.style.position = "absolute"; progressLabel.style.top = "${layout.percentTop}px"; progressLabel.style.left = "${layout.percentLeft}px"; progressLabel.style.width = "${layout.percentWidth}px"; progressLabel.style.textAlign = "${layout.percentTextAlign}"; progressLabel.style.display = "block"; progressLabel.style.transform = "none"; progressLabel.style.lineHeight = "1"; progressLabel.style.fontWeight = "bold"; progressLabel.style.zIndex = "999";`);
      } else {
         // Regex fallback for already modified versions
         content = content.replace(/progressLabel\.style\.fontSize = "[^"]+";[^\n]+progressLabel\.style\.textAlign = "[^"]+";/, `progressLabel.style.fontSize = "${layout.progressFontSize}px"; progressLabel.style.position = "absolute"; progressLabel.style.top = "${layout.percentTop}px"; progressLabel.style.left = "${layout.percentLeft}px"; progressLabel.style.width = "${layout.percentWidth}px"; progressLabel.style.textAlign = "${layout.percentTextAlign}";`);
      }

      content = content.replace('progressBar.style.backgroundColor = "#aa0000";', `progressBar.style.backgroundColor = "${colors.progressBarColor}";`);
      
      // Injecter le pourcentage dans updateProgress
      if (layout.showPercentage) {
        content = content.replace('progressLabel.textContent = message;', `progressLabel.textContent = message + " (" + percent + "%)";`);
      }

      // Couleurs des logs (uiLog) - remplacement exhaustif
      content = content.replace(/logEntry\.style\.color = "red";/g, `logEntry.style.color = "${colors.logErrorColor}";`);
      content = content.replace(/logEntry\.style\.color = "lightgreen";/g, `logEntry.style.color = "${colors.logSuccessColor}";`);
      content = content.replace(/logEntry\.style\.color = "yellow";/g, `logEntry.style.color = "${colors.logWarningColor}";`);
      // Le dernier remplacement pour le gris par défaut
      content = content.replace(/logEntry\.style\.color = "#ccc";/g, `logEntry.style.color = "${colors.logInfoColor}";`);

      return content;
    } catch (e) {
      console.error("Erreur lors de la lecture de main.js", e);
      return "// Erreur: Impossible de charger main.js";
    }
  };

  const handleDownload = async () => {
    const content = await generateFullJS();
    const blob = new Blob([content], { type: 'application/javascript;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'export.js';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    URL.revokeObjectURL(url);
  };

  return (
    <div className="flex h-screen bg-[#0A0B0E] text-[#E0E2E6] font-sans overflow-hidden">
      {/* Sidebar: Editor */}
      <aside className="w-[420px] border-r border-[#1E2028] bg-[#0F1115] flex flex-col overflow-hidden shrink-0 shadow-2xl">
        {/* Header */}
        <div className="p-8 pb-6 border-b border-[#1E2028]">
          <div className="flex items-center gap-4 mb-6">
            <div className="w-10 h-10 bg-indigo-600 rounded-lg flex items-center justify-center shadow-lg shadow-indigo-900/40">
              <Palette className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-base font-bold tracking-tight text-white">Y2JB UI Designer</h2>
              <p className="text-[10px] text-white/30 uppercase tracking-widest leading-none mt-1">v0.5 Compatible</p>
            </div>
          </div>

          <div className="flex bg-[#1E2028] p-1 rounded-xl items-center ring-1 ring-white/5">
            <button 
              onClick={() => setActiveTab('text')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${activeTab === 'text' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
            >
              <Type className="w-3.5 h-3.5" /> Textes
            </button>
            <button 
              onClick={() => setActiveTab('color')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${activeTab === 'color' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
            >
              <Palette className="w-3.5 h-3.5" /> Couleurs
            </button>
            <button 
              onClick={() => setActiveTab('layout')}
              className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-lg text-[10px] font-bold uppercase transition-all ${activeTab === 'layout' ? 'bg-indigo-600 text-white shadow-lg' : 'text-white/40 hover:text-white'}`}
            >
              <Layout className="w-3.5 h-3.5" /> Mise en page
            </button>
          </div>
        </div>

        <div className="flex-1 overflow-y-auto p-8 pt-6 space-y-8 scroll-smooth scrollbar-hide">
          {activeTab === 'text' && (
            <div className="space-y-6">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-indigo-400/60 uppercase tracking-[0.2em] flex items-center gap-2 px-1">Titre Interface</label>
                <input
                  type="text"
                  value={texts.titleText}
                  onChange={(e) => handleTextChange('titleText', e.target.value)}
                  className="w-full bg-[#1E2028] border border-white/5 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-mono text-white"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-indigo-400/60 uppercase tracking-[0.2em] flex items-center gap-2 px-1">Version Exploit</label>
                <input
                  type="text"
                  value={texts.versionString}
                  onChange={(e) => handleTextChange('versionString', e.target.value)}
                  className="w-full bg-[#1E2028] border border-white/5 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-mono text-white"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-indigo-400/60 uppercase tracking-[0.2em] flex items-center gap-2 px-1">Autoloader Ver.</label>
                <input
                  type="text"
                  value={texts.autoloaderVersion}
                  onChange={(e) => handleTextChange('autoloaderVersion', e.target.value)}
                  className="w-full bg-[#1E2028] border border-white/5 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-mono text-white"
                />
              </div>

              <div className="space-y-2">
                <label className="text-[10px] font-bold text-indigo-400/60 uppercase tracking-[0.2em] flex items-center gap-2 px-1">Texte Progression</label>
                <input
                  type="text"
                  value={texts.progressText}
                  onChange={(e) => handleTextChange('progressText', e.target.value)}
                  className="w-full bg-[#1E2028] border border-white/5 rounded-xl px-4 py-3 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500/20 focus:border-indigo-500/50 transition-all font-mono text-white"
                />
              </div>
            </div>
          )}

          {activeTab === 'color' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between mb-2">
                <label className="text-[11px] font-bold text-indigo-400/60 uppercase tracking-[0.1em]">Fond d'Écran</label>
                <button 
                  onClick={() => {
                    setUseBgImage(!useBgImage);
                    if (!useBgImage) setBgTimestamp(Date.now());
                  }}
                  className={`text-[9px] font-bold px-3 py-1.5 rounded-lg transition-all ${useBgImage ? 'bg-indigo-600 text-white' : 'bg-white/5 text-white/40 hover:bg-white/10 ring-1 ring-white/10'}`}
                >
                  {useBgImage ? 'IMAGE (background.jpg)' : 'COULEUR UNIQUE'}
                </button>
              </div>

              <div className="grid grid-cols-1 gap-3">
                {Object.entries(colors).map(([key, value]) => {
                  if (key === 'bgColor' && useBgImage) return null;
                  return (
                    <React.Fragment key={key}>
                      <div className="flex items-center justify-between bg-[#1E2028]/40 p-3 rounded-xl border border-white/5 hover:border-indigo-500/20 transition-all group">
                        <div className="flex items-center gap-4">
                          <div className="relative w-10 h-10 rounded-lg overflow-hidden ring-2 ring-white/5 group-hover:ring-indigo-500/50 transition-all">
                            <input
                              type="color"
                              value={value}
                              onChange={(e) => handleColorChange(key as keyof typeof INITIAL_COLORS, e.target.value)}
                              className="absolute inset-[-10px] w-[150%] h-[150%] cursor-pointer"
                            />
                          </div>
                          <span className="text-[11px] text-white/70 font-bold uppercase tracking-tight">{COLOR_LABELS[key as keyof typeof INITIAL_COLORS]}</span>
                        </div>
                        <span className="text-[9px] font-mono text-white/20 group-hover:text-indigo-400 transition-colors uppercase">{value}</span>
                      </div>
                      {(key === 'logBgColor' || key === 'borderColor') && (
                        <div className="mt-[-8px] px-1 pb-2">
                          <div className="flex justify-between items-center mb-1">
                            <span className="text-[9px] text-white/30 uppercase font-bold">Opacité</span>
                            <span className="text-[9px] text-indigo-400 font-mono">{(key === 'logBgColor' ? layout.logOpacity : layout.borderOpacity) * 100}%</span>
                          </div>
                          <input 
                            type="range" 
                            min="0" 
                            max="1" 
                            step="0.01" 
                            value={key === 'logBgColor' ? layout.logOpacity : layout.borderOpacity}
                            onChange={(e) => handleLayoutChange(key === 'logBgColor' ? 'logOpacity' : 'borderOpacity', parseFloat(e.target.value))}
                            className="w-full h-1 bg-white/5 rounded-full appearance-none accent-indigo-500 cursor-pointer"
                          />
                        </div>
                      )}
                    </React.Fragment>
                  );
                })}
              </div>
            </div>
          )}

          {activeTab === 'layout' && (
            <div className="space-y-8 animate-in fade-in slide-in-from-right-4 duration-300">
              {/* Titre Controls */}
              <div className="space-y-4">
                <h3 className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-indigo-500/20 pb-2">Titre</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Taille</label>
                    <input type="number" value={layout.titleFontSize} onChange={(e) => handleLayoutChange('titleFontSize', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position Y</label>
                    <input type="number" value={layout.titleTop} onChange={(e) => handleLayoutChange('titleTop', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position X</label>
                    <input type="number" value={layout.titleLeft} onChange={(e) => handleLayoutChange('titleLeft', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Largeur</label>
                    <input type="number" value={layout.titleWidth} onChange={(e) => handleLayoutChange('titleWidth', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="flex bg-[#1E2028] p-1 rounded-lg ring-1 ring-white/5">
                  {(['left', 'center', 'right'] as const).map(align => (
                    <button key={align} onClick={() => handleLayoutChange('titleTextAlign', align)} className={`flex-1 py-1 rounded-md text-[9px] font-bold uppercase ${layout.titleTextAlign === align ? 'bg-indigo-500 text-white' : 'text-white/30'}`}>{align}</button>
                  ))}
                </div>
              </div>

              {/* Log Controls */}
              <div className="space-y-4">
                <h3 className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-indigo-500/20 pb-2">Terminal</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position Y</label>
                    <input type="number" value={layout.logTop} onChange={(e) => handleLayoutChange('logTop', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position X</label>
                    <input type="number" value={layout.logLeft} onChange={(e) => handleLayoutChange('logLeft', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Largeur</label>
                    <input type="number" value={layout.logWidth} onChange={(e) => handleLayoutChange('logWidth', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Hauteur</label>
                    <input type="number" value={layout.logHeight} onChange={(e) => handleLayoutChange('logHeight', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="space-y-1">
                  <label className="text-[10px] text-white/30 ml-1">Taille Texte</label>
                  <input type="number" value={layout.logFontSize} onChange={(e) => handleLayoutChange('logFontSize', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                </div>
              </div>

              {/* Bar Controls */}
              <div className="space-y-4">
                <h3 className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-indigo-500/20 pb-2">Progress Bar</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position Y</label>
                    <input type="number" value={layout.barTop} onChange={(e) => handleLayoutChange('barTop', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position X</label>
                    <input type="number" value={layout.barLeft} onChange={(e) => handleLayoutChange('barLeft', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Largeur</label>
                    <input type="number" value={layout.barWidth} onChange={(e) => handleLayoutChange('barWidth', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Hauteur</label>
                    <input type="number" value={layout.barHeight} onChange={(e) => handleLayoutChange('barHeight', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Courbe</label>
                    <input type="number" value={layout.barBorderRadius} onChange={(e) => handleLayoutChange('barBorderRadius', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Bordure</label>
                    <input type="number" value={layout.barBorderWidth} onChange={(e) => handleLayoutChange('barBorderWidth', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
              </div>

              {/* Percent Controls */}
              <div className="space-y-4">
                <h3 className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-indigo-500/20 pb-2">Label Progression</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position Y</label>
                    <input type="number" value={layout.percentTop} onChange={(e) => handleLayoutChange('percentTop', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Position X</label>
                    <input type="number" value={layout.percentLeft} onChange={(e) => handleLayoutChange('percentLeft', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Taille Texte</label>
                    <input type="number" value={layout.progressFontSize} onChange={(e) => handleLayoutChange('progressFontSize', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                  <div className="space-y-1">
                    <label className="text-[10px] text-white/30 ml-1">Largeur</label>
                    <input type="number" value={layout.percentWidth} onChange={(e) => handleLayoutChange('percentWidth', parseInt(e.target.value) || 0)} className="w-full bg-[#1E2028] text-white p-2 rounded-lg text-sm border border-white/5 font-mono" />
                  </div>
                </div>
                <div className="flex bg-[#1E2028] p-1 rounded-lg ring-1 ring-white/5">
                  {(['left', 'center', 'right'] as const).map(align => (
                    <button key={align} onClick={() => handleLayoutChange('percentTextAlign', align)} className={`flex-1 py-1 rounded-md text-[9px] font-bold uppercase ${layout.percentTextAlign === align ? 'bg-indigo-500 text-white' : 'text-white/30'}`}>{align}</button>
                  ))}
                </div>
                <button 
                  onClick={() => handleLayoutChange('showPercentage', !layout.showPercentage)}
                  className={`w-full py-3 rounded-xl text-[10px] font-bold uppercase transition-all ring-1 ${layout.showPercentage ? 'bg-indigo-600 text-white ring-indigo-500 shadow-lg' : 'bg-white/5 text-white/40 ring-white/10 hover:bg-white/10'}`}
                >
                  {layout.showPercentage ? 'Pourcentage Activé ✔' : 'Afficher Pourcentage'}
                </button>
              </div>

              {/* Font Choice */}
              <div className="space-y-4">
                <h3 className="text-[11px] font-bold text-indigo-400 uppercase tracking-widest border-b border-indigo-500/20 pb-2">Polices</h3>
                <div className="space-y-2">
                  <button onClick={() => { handleLayoutChange('titleFont', 'monospace'); handleLayoutChange('logFont', 'monospace'); }} className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${layout.titleFont === 'monospace' ? 'bg-indigo-600/10 border-indigo-600 text-white' : 'bg-white/5 border-white/5 text-white/40'}`}>
                    <span className="font-mono text-xs">Monospace (Code)</span>
                    {layout.titleFont === 'monospace' && <Check className="w-4 h-4" />}
                  </button>
                  <button onClick={() => { handleLayoutChange('titleFont', 'Arial, sans-serif'); handleLayoutChange('logFont', 'Arial, sans-serif'); }} className={`w-full flex items-center justify-between px-4 py-3 rounded-xl border transition-all ${layout.titleFont !== 'monospace' ? 'bg-indigo-600/10 border-indigo-600 text-white' : 'bg-white/5 border-white/5 text-white/40'}`}>
                    <span className="font-sans text-xs font-bold">Sans-Serif (Moderne)</span>
                    {layout.titleFont !== 'monospace' && <Check className="w-4 h-4" />}
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>

        {/* Footer Actions */}
        <div className="p-8 border-t border-[#1E2028] bg-[#0C0E12] space-y-4 shadow-[0_-10px_30px_rgba(0,0,0,0.5)]">
          <button onClick={resetToDefault} className="w-full py-3 text-white/20 hover:text-indigo-400 transition-colors text-[10px] font-bold uppercase tracking-widest underline underline-offset-4">Réinitialiser tout</button>
          <button
            onClick={handleDownload}
            className="w-full flex items-center justify-center gap-3 bg-indigo-600 hover:bg-indigo-500 text-white py-4 rounded-xl text-sm font-bold shadow-2xl shadow-indigo-900/40 transition-all transform active:scale-95 hover:translate-y-[-2px] group"
          >
            <Download className="w-5 h-5 group-hover:animate-bounce" />
            Télécharger main.js
          </button>
        </div>
      </aside>

      {/* Main Preview Area */}
      <main className="flex-1 bg-[#050608] relative flex flex-col items-center justify-center p-4 overflow-hidden" ref={containerRef}>
        <div className="absolute top-6 left-8 flex items-center gap-3 opacity-30 select-none z-20">
          <div className="w-2 h-2 rounded-full bg-indigo-500"></div>
          <span className="text-xs font-bold uppercase tracking-[0.4em] text-white">Interface Emulator</span>
        </div>

        {/* Scalable Container - 16:9 Force */}
        <div className="w-full flex-1 min-h-0 flex items-center justify-center p-8">
          <div className="relative w-full h-full flex items-center justify-center overflow-hidden">
            <motion.div
              animate={{ scale: scale }}
              transition={{ type: 'spring', damping: 25, stiffness: 120 }}
              id="emulator-viewport"
              className="relative shadow-[0_50px_200px_-20px_rgba(0,0,0,1)] rounded-sm overflow-hidden ring-1 ring-white/10 shrink-0"
              style={{
                width: '1920px',
                height: '1080px',
                backgroundColor: colors.bgColor,
                backgroundImage: useBgImage ? `url('/background.jpg?t=${bgTimestamp}')` : 'none',
                backgroundSize: 'cover',
                backgroundPosition: 'center',
                transformOrigin: 'center center'
              }}
            >
              {/* Live Content */}
              <div className="w-full h-full relative" onClick={() => setSelectedElement(null)}>
                
                {/* Titre - Interactive */}
                <motion.div 
                  drag
                  dragMomentum={false}
                  onDrag={(e, info) => {
                    setLayout(prev => ({
                      ...prev,
                      titleTop: Math.round(prev.titleTop! + info.delta.y / scale),
                      titleLeft: Math.round(prev.titleLeft! + info.delta.x / scale)
                    }));
                  }}
                  onClick={(e) => { e.stopPropagation(); setSelectedElement('title'); }}
                  className={`absolute cursor-move group/item z-20 ${selectedElement === 'title' ? 'ring-2 ring-indigo-500 ring-offset-4 ring-offset-black/50' : 'hover:ring-1 hover:ring-white/20'}`}
                  style={{ 
                    top: `${layout.titleTop}px`,
                    left: `${layout.titleLeft}px`,
                    width: `${layout.titleWidth}px`,
                    textAlign: layout.titleTextAlign as any,
                  }}
                >
                  <h1 className="font-bold tracking-tighter" style={{ fontSize: `${layout.titleFontSize}px`, color: colors.titleColor, fontFamily: layout.titleFont }}>
                    {texts.titleText}
                  </h1>
                
                {/* Resize Handle for Title Width */}
                {selectedElement === 'title' && (
                  <div 
                    className="absolute right-[-10px] top-1/2 -translate-y-1/2 w-4 h-20 bg-indigo-500 rounded-full cursor-ew-resize pointer-events-auto"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const startX = e.clientX;
                      const startWidth = layout.titleWidth!;
                      const onMove = (moveEvent: PointerEvent) => {
                        const delta = (moveEvent.clientX - startX) / scale;
                        setLayout(prev => ({ ...prev, titleWidth: Math.max(100, Math.round(startWidth + delta)) }));
                      };
                      const onUp = () => {
                        window.removeEventListener('pointermove', onMove);
                        window.removeEventListener('pointerup', onUp);
                      };
                      window.addEventListener('pointermove', onMove);
                      window.addEventListener('pointerup', onUp);
                    }}
                  />
                )}
              </motion.div>

              {/* Console Logs - Interactive */}
              <motion.div
                drag
                dragMomentum={false}
                onDrag={(e, info) => {
                  setLayout(prev => ({
                    ...prev,
                    logTop: Math.round(prev.logTop! + info.delta.y / scale),
                    logLeft: Math.round(prev.logLeft! + info.delta.x / scale)
                  }));
                }}
                onClick={(e) => { e.stopPropagation(); setSelectedElement('log'); }}
                className={`absolute p-[48px] overflow-hidden flex flex-col justify-end cursor-move group/item z-10 ${selectedElement === 'log' ? 'ring-2 ring-indigo-500 ring-offset-4 ring-offset-black/50' : 'hover:ring-1 hover:ring-white/20'}`}
                style={{
                  width: `${layout.logWidth}px`,
                  height: `${layout.logHeight}px`,
                  top: `${layout.logTop}px`,
                  left: `${layout.logLeft}px`,
                  backgroundColor: hexToRgba(colors.logBgColor, layout.logOpacity),
                  border: `${layout.logBorderWidth}px solid ${hexToRgba(colors.borderColor, layout.borderOpacity)}`,
                  borderRadius: `${layout.logBorderRadius}px`,
                  fontSize: `${layout.logFontSize}px`,
                  fontFamily: layout.logFont,
                }}
              >
                <div className="space-y-4 pointer-events-none">
                  <div style={{ color: colors.logInfoColor }}>Autoloader {texts.autoloaderVersion} by PLK</div>
                  <div style={{ color: colors.logWarningColor }}>Running userland exploit...</div>
                  <div style={{ color: colors.logSuccessColor }}>{texts.versionString}</div>
                  <div style={{ color: colors.logWarningColor }}>Running kernel exploit...</div>
                  <div style={{ color: colors.logSuccessColor }}>Exploit success!</div>
                  <div style={{ color: colors.logInfoColor }}>Autoload finished.</div>
                </div>

                {/* Resize Handle for Logs */}
                {selectedElement === 'log' && (
                  <div 
                    className="absolute right-0 bottom-0 w-12 h-12 bg-indigo-500 rounded-tl-3xl cursor-nwse-resize pointer-events-auto flex items-center justify-center"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const startX = e.clientX;
                      const startY = e.clientY;
                      const startWidth = layout.logWidth!;
                      const startHeight = layout.logHeight!;
                      const onMove = (moveEvent: PointerEvent) => {
                        const deltaX = (moveEvent.clientX - startX) / scale;
                        const deltaY = (moveEvent.clientY - startY) / scale;
                        setLayout(prev => ({ 
                          ...prev, 
                          logWidth: Math.max(200, Math.round(startWidth + deltaX)),
                          logHeight: Math.max(100, Math.round(startHeight + deltaY))
                        }));
                      };
                      const onUp = () => {
                        window.removeEventListener('pointermove', onMove);
                        window.removeEventListener('pointerup', onUp);
                      };
                      window.addEventListener('pointermove', onMove);
                      window.addEventListener('pointerup', onUp);
                    }}
                  >
                    <div className="w-4 h-4 border-r-2 border-b-2 border-white rotate-45 mb-1 ml-1" />
                  </div>
                )}
              </motion.div>

              {/* Progress Bar Container - Interactive */}
              <motion.div
                drag
                dragMomentum={false}
                onDrag={(e, info) => {
                  setLayout(prev => ({
                    ...prev,
                    barTop: Math.round(prev.barTop! + info.delta.y / scale),
                    barLeft: Math.round(prev.barLeft! + info.delta.x / scale)
                  }));
                }}
                onClick={(e) => { e.stopPropagation(); setSelectedElement('bar'); }}
                className={`absolute overflow-hidden flex items-center justify-center font-bold uppercase tracking-widest cursor-move group/item z-20 ${selectedElement === 'bar' ? 'ring-2 ring-indigo-500 ring-offset-4 ring-offset-black/50' : 'hover:ring-1 hover:ring-white/20'}`}
                style={{
                  width: `${layout.barWidth}px`,
                  height: `${layout.barHeight}px`,
                  top: `${layout.barTop}px`,
                  left: `${layout.barLeft}px`,
                  backgroundColor: colors.barBgColor,
                  border: `${layout.barBorderWidth}px solid ${hexToRgba(colors.borderColor, layout.borderOpacity)}`,
                  borderRadius: `${layout.barBorderRadius}px`,
                  fontFamily: layout.titleFont,
                }}
              >
                <div
                  className="absolute left-0 top-0 bottom-0 shadow-[0_0_20px_rgba(255,255,255,0.2)] pointer-events-none"
                  style={{ width: '70%', backgroundColor: colors.progressBarColor }}
                />

                {/* Resize Handle for Progress Bar */}
                {selectedElement === 'bar' && (
                  <div 
                    className="absolute right-0 bottom-0 w-10 h-10 bg-indigo-500 rounded-tl-2xl cursor-nwse-resize pointer-events-auto"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const startX = e.clientX;
                      const startY = e.clientY;
                      const startWidth = layout.barWidth!;
                      const startHeight = layout.barHeight!;
                      const onMove = (moveEvent: PointerEvent) => {
                        const deltaX = (moveEvent.clientX - startX) / scale;
                        const deltaY = (moveEvent.clientY - startY) / scale;
                        setLayout(prev => ({ 
                          ...prev, 
                          barWidth: Math.max(100, Math.round(startWidth + deltaX)),
                          barHeight: Math.max(1, Math.round(startHeight + deltaY))
                        }));
                      };
                      const onUp = () => {
                        window.removeEventListener('pointermove', onMove);
                        window.removeEventListener('pointerup', onUp);
                      };
                      window.addEventListener('pointermove', onMove);
                      window.addEventListener('pointerup', onUp);
                    }}
                  />
                )}
              </motion.div>

              {/* Independent Progress Label - Interactive */}
              <motion.div
                drag
                dragMomentum={false}
                onDrag={(e, info) => {
                  setLayout(prev => ({
                    ...prev,
                    percentTop: Math.round(prev.percentTop! + info.delta.y / scale),
                    percentLeft: Math.round(prev.percentLeft! + info.delta.x / scale)
                  }));
                }}
                onClick={(e) => { e.stopPropagation(); setSelectedElement('percent'); }}
                className={`absolute font-bold uppercase tracking-widest cursor-move group/item z-30 ${selectedElement === 'percent' ? 'ring-2 ring-indigo-500 ring-offset-4 ring-offset-black/50' : 'hover:ring-1 hover:ring-white/20'}`}
                style={{
                  top: `${layout.percentTop}px`,
                  left: `${layout.percentLeft}px`,
                  width: `${layout.percentWidth}px`,
                  textAlign: layout.percentTextAlign,
                  display: 'block',
                  lineHeight: '1',
                  zIndex: 30
                }}
              >
                <span className="pointer-events-none block w-full" style={{ fontSize: `${layout.progressFontSize}px`, color: colors.progressLabelColor, fontFamily: layout.titleFont }}>
                   {texts.progressText} {layout.showPercentage ? '(70%)' : ''}
                </span>

                {/* Resize Handle for Label Width */}
                {selectedElement === 'percent' && (
                  <div 
                    className="absolute right-[-8px] top-1/2 -translate-y-1/2 w-3 h-10 bg-indigo-500 rounded-full cursor-ew-resize pointer-events-auto"
                    onPointerDown={(e) => {
                      e.stopPropagation();
                      const startX = e.clientX;
                      const startWidth = layout.percentWidth!;
                      const onMove = (moveEvent: PointerEvent) => {
                        const delta = (moveEvent.clientX - startX) / scale;
                        setLayout(prev => ({ ...prev, percentWidth: Math.max(50, Math.round(startWidth + delta)) }));
                      };
                      const onUp = () => {
                        window.removeEventListener('pointermove', onMove);
                        window.removeEventListener('pointerup', onUp);
                      };
                      window.addEventListener('pointermove', onMove);
                      window.addEventListener('pointerup', onUp);
                    }}
                  />
                )}
              </motion.div>
            </div>
          </motion.div>
        </div>
      </div>

      <div className="absolute bottom-6 right-8 text-[9px] text-white/20 font-mono tracking-widest uppercase flex items-center gap-6 z-20">
        <span className="text-indigo-400/50">Auto-Scale: {(scale * 100).toFixed(1)}%</span>
        <span>1920x1080 Viewport</span>
      </div>
    </main>

      <style dangerouslySetInnerHTML={{ __html: `
        .scrollbar-hide::-webkit-scrollbar { display: none; }
        .scrollbar-hide { -ms-overflow-style: none; scrollbar-width: none; }
        .shrink-0 { flex-shrink: 0; }
        @keyframes bounce {
          0%, 100% { transform: translateY(0); }
          50% { transform: translateY(-3px); }
        }
        .group-hover\\:animate-bounce { animation: bounce 0.5s ease infinite; }
      `}} />
    </div>
  );
}
