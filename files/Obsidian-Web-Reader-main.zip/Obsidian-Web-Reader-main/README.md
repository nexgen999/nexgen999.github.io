# 💎 Obsidian Web Reader (v1.0)

**Développé par [nexgen999](https://github.com/nexgen999)**

Obsidian Web Reader est une interface web élégante, légère et entièrement statique conçue pour héberger et lire votre vault Obsidian directement sur GitHub Pages. Profitez d'une expérience de lecture fluide avec une navigation intelligente basée sur vos dossiers réels.

![Aperçu](https://obsidian.md/favicon.ico) <!-- Vous pouvez remplacer par un vrai screenshot -->

## ✨ Fonctionnalités

- 📂 **Navigation Intelligente** : Génération automatique d'arborescences à partir des chemins de fichiers.
- 📐 **Interface Flexible** : Barre latérale redimensionnable et 3 modes de vue (Explorateur, Cascade, Liste).
- 🎨 **Thèmes Dynamiques** : Support des modes Dark, Light et Dim.
- 🔡 **Personnalisation Totale** : Choix parmi 20 polices professionnelles Google Fonts et réglages de taille séparés pour le menu et le contenu.
- 📱 **100% Responsive** : Expérience optimisée pour Mobile, Tablette et Bureau.
- 🚀 **Zéro Backend** : Pas de base de données, pas de serveur. Juste du HTML/JS statique.

## 📁 Fonctionnement du `navigation.md`

Le fichier `navigation.md` est le cœur de votre navigation. Il définit les sections et les fichiers à afficher.

### Structure de base :
Utilisez des titres (`#`) pour créer des catégories racines, et des listes (`-`) pour les chemins de vos fichiers.

```markdown
# MA SECTION
- notes/mon-fichier.md
- notes/dossier/autre-fichier.md
```

### Arborescence Automatique :
Le système analyse les chemins (`/`) pour créer des dossiers compressibles dynamiquement :
- `- notes/xbox/applications/guide.md` créera automatiquement :
  - `notes` (Dossier)
    - `xbox` (Sous-dossier)
      - `applications` (Sous-dossier)
        - `guide` (Fichier)

## 🚀 Installation Rapide

1. **Forkez** ou copiez le contenu du dossier `github` dans un nouveau dépôt.
2. **Uploadez** vos fichiers `.md` dans le dossier `notes/` (ou à la racine).
3. **Configurez** votre `navigation.md` avec les chemins de vos fichiers.
4. **Activez GitHub Pages** dans les paramètres de votre dépôt (`Settings > Pages > Branch: main`).
5. **C'est fini !** Votre vault est en ligne.

## ⚙️ Paramètres
Cliquez sur l'icône ⚙️ pour accéder aux réglages de polices, thèmes et tailles. Vos préférences sont sauvegardées dans votre navigateur.

---
*Fait avec ❤️ par nexgen999*
