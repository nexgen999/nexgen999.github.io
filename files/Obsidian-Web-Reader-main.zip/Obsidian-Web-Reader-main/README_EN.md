# 💎 Obsidian Web Reader (v1.0)

**Developed by [nexgen999](https://github.com/nexgen999)**

Obsidian Web Reader is a sleek, lightweight, and fully static web interface designed to host and read your Obsidian vault directly on GitHub Pages. Enjoy a seamless reading experience with intelligent navigation based on your actual folder structure.

![Preview](https://obsidian.md/favicon.ico) <!-- Replace with a real screenshot if available -->

## ✨ Features

- 📂 **Intelligent Navigation**: Automatic tree generation from file paths.
- 📐 **Flexible UI**: Resizable sidebar and 3 view modes (Explorer, Cascade, List).
- 🎨 **Dynamic Themes**: Support for Dark, Light, and Dim modes.
- 🔡 **Total Customization**: Choose from 20 professional Google Fonts with separate size settings for Menu and Content.
- 📱 **100% Responsive**: Optimized experience for Mobile, Tablet, and Desktop.
- 🚀 **Zero Backend**: No database, no server. Just static HTML/JS.

## 📁 How `navigation.md` Works

The `navigation.md` file is the heart of your site. It defines the sections and files to be displayed.

### Basic Structure:
Use headers (`#`) to create root categories, and lists (`-`) for your file paths.

```markdown
# MY SECTION
- notes/my-file.md
- notes/folder/other-file.md
```

### Automatic Tree:
The system parses paths (`/`) to create dynamic collapsible folders:
- `- notes/xbox/apps/guide.md` will automatically create:
  - `notes` (Folder)
    - `xbox` (Subfolder)
      - `apps` (Subfolder)
        - `guide` (File)

## 🚀 Quick Start

1. **Fork** or copy the content of the `github` folder into a new repository.
2. **Upload** your `.md` files into the `notes/` folder (or root).
3. **Configure** your `navigation.md` with your file paths.
4. **Enable GitHub Pages** in your repo settings (`Settings > Pages > Branch: main`).
5. **Done!** Your vault is live.

## ⚙️ Settings
Click the ⚙️ icon to access font, theme, and size settings. Your preferences are saved in your browser.

---
*Made with ❤️ by nexgen999*
